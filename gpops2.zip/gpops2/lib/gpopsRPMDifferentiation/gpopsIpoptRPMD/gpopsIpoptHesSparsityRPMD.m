function probinfo = gpopsIpoptHesSparsityRPMD(probinfo)

% get Hessian nonlinear index
[hespat, probinfo] = gpopsHesPatRPMD(probinfo);
probinfo.hespat = hespat;