function probinfo = gpopsIpoptHesSparsityRPMI(probinfo)

% get Hessian nonlinear index
[hespat, probinfo] = gpopsHesPatRPMI(probinfo);
probinfo.hespat = hespat;