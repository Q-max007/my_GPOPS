function output = tumorAntiAngiogenesisEndpoint(input)

pf = input.phase.finalstate(1);
output.objective = pf;


