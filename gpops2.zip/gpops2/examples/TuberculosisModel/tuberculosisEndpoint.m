%-----------------------------------------%
% Begin Function:  tuberculosisEndpoint.m %
%-----------------------------------------%
function output = tuberculosisEndpoint(input)

output.objective = input.phase.integral;

%-----------------------------------------%
% End Function:  tuberculosisEndpoint.m   %
%-----------------------------------------%
