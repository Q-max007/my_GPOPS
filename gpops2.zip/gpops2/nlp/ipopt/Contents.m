%--------------------------------------------------------------------------------%
%                    IPOPT MATLAB Files for Use with GPOPS-II                    %
%--------------------------------------------------------------------------------%
% This directory contains the precompiled IPOPT mex files for use with GPOPS-II. %
% The required paths are set automatically by running the path setup script.     %
% These mex files use the multifrontal linear solver MUMPS.  If you need mex     %
% files that use other linear solvers, you will be required to compile these     %
% other mex files yourself.                                                      %
%--------------------------------------------------------------------------------%
