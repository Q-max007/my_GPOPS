% Contents.m
%
% goddardRocketMain.m:     The main file for the Goddard Rocket Problem
% goddardRocketCost.m:     The cost function file for the Goddard Rocket Problem
% goddardRocketDae.m :     The differential algebraic equations file for the
%                          Goddard Rocket Problem
