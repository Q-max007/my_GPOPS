% Contents.m
%
% linearTangentMain.m: The main file for the Linear Tangent Steering Problem
% linearTangentCost.m: The cost function file for the 
%                      Linear Tangent Steering Problem 
% linearTangentDae.m : The differential algebraic equations file for the
%                      Linear Tangent Steering Problem 
