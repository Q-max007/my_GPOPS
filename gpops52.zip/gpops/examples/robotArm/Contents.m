% Contents.m
%
% robotArmMain.m:  The main file for the Robot Arm Problem
% robotArmCost.m:  The cost function for the Robot Arm Problem
% robotArmDae.m:   The differential-algebraic function for the Robot Arm Problem
