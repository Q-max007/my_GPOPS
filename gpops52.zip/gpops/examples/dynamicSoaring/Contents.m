% Contents.m
%
% dynamicSoaringMain.m:     The main file for the Dynamic Soaring Problem
% dynamicSoaringCost.m:     The cost function file for the Dynamic Soaring Problem
% dynamicSoaringDae.m :     The differential-algebraic equations file for the
%                           Dynamic Soaring Problem
