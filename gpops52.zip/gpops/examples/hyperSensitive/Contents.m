% Contents.m
%
% hyperSensitiveMain.m:     The main file for the Hyper-Sensitive Problem
% hyperSensitiveCost.m:     The cost function file for the Hyper-Sensitive
%                           Problem
% hyperSensitiveDae.m :     The differential algebraic equations file for the
%                           Hyper-Sensitive Problem
