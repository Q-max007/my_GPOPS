% Contents.m
%
% orbitRaisingMain.m:  The main file for the Orbit-Raising Problem
% orbitRaisingCost.m:  The cost function file for the Orbit-Raising Problem
% orbitRaisingDae.m :  The differential algebraic equations file for the Orbit-Raising Problem
