% Contents.m
%
% brysonDenhamMain.m:     The main file for the Bryson Denham Problem
% brysonDenhamCost.m:     The cost function file for the Bryson Denham Problem
% brysonDenhamDae.m :     The differential-algebraic equations file for the Bryson Denham Problem
% brysonDenhamEvent.m:    The events file for the Bryson Denham Problem
