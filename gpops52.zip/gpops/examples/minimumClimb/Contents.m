% Contents.m
%
% minimumClimbMain.m: The main file for the Minimum Time-to-Climb of a Supersonic Aircraft
% minimumClimbCost.m: The cost function for the Minimum Time-to-Climb of a Supersonic Aircraft
% minimumClimbDae.m : The differential-algebraic equations file for the Minimum Time-to-Climb of a Supersonic Aircraft
