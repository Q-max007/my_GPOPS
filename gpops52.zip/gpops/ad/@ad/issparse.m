function y = issparse(x)

% AD implementation of issparse.m
% Code written by David Benson
% August 2011

y = issparse(x.value);


