function y = numel(x)

% AD implementation of numel.m
% Code written by David Benson
% August 2011

y = numel(x.value);


