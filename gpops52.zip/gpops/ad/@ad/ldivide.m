function y=ldivide(a,b)

% AD implementation of ldivide.m
% Code written by Ilyssa Sanders and Anil V. Rao
% January 2009

y = b./a;
