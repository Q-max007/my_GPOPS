function x = sparse(x)

% AD implementation of sparse.m
% Code written by Ilyssa Sanders and Anil V. Rao
% January 2009

x.value = sparse(x.value);


